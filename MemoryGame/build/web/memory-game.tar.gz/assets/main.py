import asyncio
import pygame
import sys, platform

from constants import *
from game import Game

if sys.platform == "emscripten":
    platform.window.canvas.style.imageRendering = "pixelated"
async def main():
    pygame.init()
    pygame.font.init()
    pygame.mixer.pre_init(44100, -16, 2, 512)
    pygame.mixer.init()

    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Memory Game")
    clock = pygame.time.Clock()
    game = Game()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                try:
                    game.handle_click(event.pos)
                except Exception as e:
                    print(f"handle_click error: {e}")

        screen.fill((GRAY))
        try:
            game.update()
        except Exception as e:
            print(f"update error: {e}")
        game.draw(screen)

        pygame.display.update()
        clock.tick(FPS)
        await asyncio.sleep(0)

asyncio.run(main())